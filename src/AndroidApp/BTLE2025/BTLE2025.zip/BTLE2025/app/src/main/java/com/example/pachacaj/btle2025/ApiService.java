package com.example.pachacaj.btle2025;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiService {
    @FormUrlEncoded
    @POST ("")
    Call<Void> enviarDatos(
            @Field("dato1") String dato1,
            @Field("dato2") String dato2
    );
}
